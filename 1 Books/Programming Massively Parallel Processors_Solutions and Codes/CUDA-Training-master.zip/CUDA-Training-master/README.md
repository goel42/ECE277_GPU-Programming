# CUDA Learning
Some CUDA projects and utilities.

Exercises and Solutions for Programming Massively Parallel Processors

Reference book: [Programming Massively Parallel Processors 3rd Edition A Hands-on Approach Authors: David Kirk Wen-mei Hwu](https://www.elsevier.com/books/programming-massively-parallel-processors/kirk/978-0-12-811986-0)
