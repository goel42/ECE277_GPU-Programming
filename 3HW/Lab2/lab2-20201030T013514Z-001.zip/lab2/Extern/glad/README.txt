https://github.com/Dav1dde/glad

Command used to generate bindings:

python main.py --profile=core --out-path=../gl_out --api=gl=4.3 --generator=c --extensions=GL_ARB_debug_output,GL_ARB_explicit_uniform_location,GL_ARB_internalformat_query2,GL_AMD_pinned_memory,GL_ARB_buffer_storage --spec=gl --no-loader
